import { lazy, Suspense, useCallback, useRef, useState } from 'react'
import { Container } from '../../../components/layout/Container'
import {
  homeTourChapters,
  homeTourDisclaimer,
  homeTourHeading,
  homeTourTagline,
} from '../../../data/homeTour'
import { ThreeErrorBoundary } from '../../../three/components/ThreeErrorBoundary'
import { useCanvasEligibility } from '../FromPlanToPlaceSection/useCanvasEligibility'
import { JourneyLine } from './JourneyLine'
import { StaticTourVisual } from './StaticTourVisual'
import { useHomeTourScrub } from './useHomeTourScrub'
import { useProximity } from './useProximity'
import styles from './HomeTourSection.module.css'

/**
 * The only place that ever references src/three/home-tour/HomeTourCanvas, so
 * Vite code-splits the whole 3D tour (scene, textures, geometry) into its own
 * chunk, loaded only when the section is near and the visit is eligible.
 */
const HomeTourCanvasLazy = lazy(() => import('../../../three/home-tour/HomeTourCanvas'))

/**
 * Home Tour — ONE house, ONE camera, ONE scroll timeline. On a desktop with
 * motion allowed and WebGL available, a pinned 100svh frame holds a real-time
 * 3D residence at dusk; scrolling moves the camera along a predetermined
 * path through nine connected spaces (see src/three/home-tour). Every other
 * visit — mobile/tablet, reduced motion, no WebGL, or a runtime failure —
 * gets the same story as a calm static block: an SVG dusk elevation and the
 * nine chapters as plain text. The chapters are always real HTML.
 */
export function HomeTourSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const pinnedRef = useRef<HTMLDivElement>(null)
  const progressRef = useRef({ value: 0 })
  const invalidateRef = useRef<(() => void) | null>(null)
  const [hasError, setHasError] = useState(false)
  const [canvasReady, setCanvasReady] = useState(false)

  const eligible = useCanvasEligibility()
  const tourActive = eligible && !hasError
  const { isNear, isVisible } = useProximity(sectionRef)

  useHomeTourScrub(pinnedRef, progressRef, invalidateRef, tourActive)

  const handleReady = useCallback((invalidate: (() => void) | null) => {
    invalidateRef.current = invalidate
    setCanvasReady(Boolean(invalidate))
  }, [])

  const renderCanvas = tourActive && isNear

  return (
    <section
      id="home-tour"
      ref={sectionRef}
      className={styles.section}
      aria-labelledby="home-tour-heading"
      data-mode={tourActive ? 'tour' : 'static'}
    >
      <div ref={pinnedRef} className={styles.pinned}>
        <div className={styles.stage}>
          <StaticTourVisual />
          {renderCanvas ? (
            <div className={styles.canvas} data-ready={canvasReady}>
              <ThreeErrorBoundary fallback={null} onError={() => setHasError(true)}>
                <Suspense fallback={null}>
                  <HomeTourCanvasLazy
                    progressRef={progressRef}
                    onReady={handleReady}
                    isVisible={isVisible}
                  />
                </Suspense>
              </ThreeErrorBoundary>
            </div>
          ) : null}
        </div>
        <div className={styles.vignette} aria-hidden="true" />

        <Container className={styles.container}>
          <div className={styles.intro}>
            <h2 id="home-tour-heading" className={styles.heading}>
              {homeTourHeading}
            </h2>
            <p className={styles.tagline}>{homeTourTagline}</p>
          </div>

          <ol className={styles.chapters} data-tour-chapters>
            {homeTourChapters.map((chapter) => (
              <li key={chapter.id} className={styles.chapter} data-tour-chapter>
                <span className={`text-mono-label ${styles.chapterIndex}`}>{chapter.index} —</span>
                <h3 className={styles.chapterTitle}>{chapter.title}</h3>
                <p className={styles.chapterCaption}>{chapter.caption}</p>
              </li>
            ))}
          </ol>
          <p className={styles.disclaimer}>{homeTourDisclaimer}</p>
        </Container>

        <JourneyLine />
      </div>
    </section>
  )
}
