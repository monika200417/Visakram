import styles from './HomeTourSection.module.css'

const nodes = [
  [70, 598],
  [190, 574],
  [330, 590],
  [450, 566],
  [590, 584],
  [720, 560],
  [850, 580],
  [980, 552],
  [1120, 570],
] as const

const trees = [
  [96, 392, 70],
  [236, 360, 54],
  [1010, 380, 66],
  [1130, 400, 58],
  [900, 420, 40],
] as const

/**
 * The static fallback for the Home Tour — shown on mobile and tablet, with
 * reduced motion, with no WebGL, or if the 3D scene fails. A single dusk
 * elevation of the same residence drawn in SVG/CSS (no Three.js, no image
 * download), with the gold light path running through nine stations. It is
 * decorative; the chapter list beside it carries the content.
 */
export function StaticTourVisual() {
  return (
    <svg
      className={styles.poster}
      viewBox="0 0 1200 675"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id="ht-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#05070e" />
          <stop offset="0.55" stopColor="#1a1328" />
          <stop offset="0.85" stopColor="#7a3519" />
          <stop offset="1" stopColor="#c0652a" />
        </linearGradient>
        <linearGradient id="ht-glow" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffe0a0" />
          <stop offset="1" stopColor="#d8964a" />
        </linearGradient>
        <linearGradient id="ht-ground" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1d1611" />
          <stop offset="1" stopColor="#0a0807" />
        </linearGradient>
        <radialGradient id="ht-pool" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffbd6e" stopOpacity="0.5" />
          <stop offset="1" stopColor="#ffbd6e" stopOpacity="0" />
        </radialGradient>
      </defs>

      <rect width="1200" height="675" fill="url(#ht-sky)" />
      {/* ridgelines and distant town lights */}
      <path
        d="M0 470 L120 420 L230 455 L360 400 L470 440 L600 405 L720 450 L860 395 L990 440 L1100 410 L1200 440 L1200 520 L0 520Z"
        fill="#171220"
      />
      <path
        d="M0 500 L150 470 L280 495 L420 462 L560 492 L700 470 L840 496 L980 466 L1100 490 L1200 478 L1200 540 L0 540Z"
        fill="#0c0a0d"
      />
      {Array.from({ length: 34 }, (_, i) => (
        <rect
          key={i}
          x={620 + ((i * 97) % 560)}
          y={496 + ((i * 53) % 26)}
          width="3"
          height="3"
          fill="#ffc27a"
          opacity="0.75"
        />
      ))}
      {/* faint architectural wireframe */}
      <g stroke="#c9a45c" strokeOpacity="0.16" fill="none" strokeWidth="1">
        <path d="M820 40 L1080 60 L1130 150 L880 130 Z M880 130 L880 230 M1130 150 L1130 250 M820 40 L820 140 L880 230 L1130 250" />
        <path d="M60 130 L220 110 L260 190 L100 210 Z" />
      </g>

      <rect y="520" width="1200" height="155" fill="url(#ht-ground)" />
      <ellipse cx="560" cy="585" rx="360" ry="46" fill="url(#ht-pool)" />

      {/* the residence: dark stone gate wall, entry portico, terrace slab, bedroom volume */}
      <rect x="120" y="360" width="250" height="150" fill="#14120f" />
      <rect x="120" y="360" width="250" height="3" fill="#ffffff" opacity="0.12" />
      <rect x="380" y="372" width="480" height="138" fill="#201c18" />
      <rect x="380" y="276" width="270" height="40" fill="#cdc2ac" />
      <rect x="380" y="316" width="270" height="56" fill="#1a1613" />
      {[420, 480, 540, 600].map((x) => (
        <rect key={x} x={x} y="322" width="6" height="50" fill="#6b4023" />
      ))}
      <rect x="500" y="352" width="230" height="20" fill="#0b0a0a" />
      <rect x="506" y="356" width="218" height="10" fill="#7a4a2a" />
      <rect x="578" y="378" width="76" height="132" fill="#6b3f22" />
      <rect x="600" y="382" width="3" height="124" fill="#c9a45c" opacity="0.5" />
      <rect x="720" y="384" width="130" height="108" fill="url(#ht-glow)" opacity="0.85" />
      {[0, 1, 2].map((i) => (
        <rect key={i} x={720 + i * 43} y="384" width="3" height="108" fill="#0b0a0a" />
      ))}
      <rect x="400" y="388" width="150" height="104" fill="url(#ht-glow)" opacity="0.5" />
      <rect x="650" y="228" width="240" height="144" fill="#171411" />
      <rect x="670" y="246" width="200" height="108" fill="url(#ht-glow)" opacity="0.9" />
      <rect x="640" y="214" width="260" height="14" fill="#0a0909" />
      <rect x="650" y="354" width="240" height="4" fill="#cdc2ac" opacity="0.7" />
      {/* lit entry steps */}
      {[0, 1, 2].map((i) => (
        <rect
          key={i}
          x={470 - i * 22}
          y={510 + i * 9}
          width={300 + i * 44}
          height="2"
          fill="#ffc27a"
          opacity="0.85"
        />
      ))}
      {/* trees, lit from below */}
      {trees.map(([x, y, r]) => (
        <g key={`${x}-${y}`}>
          <rect x={x - 4} y={y} width="8" height={520 - y} fill="#1d140e" />
          <circle cx={x} cy={y - r * 0.2} r={r} fill="#16301a" />
          <circle cx={x - r * 0.25} cy={y - r * 0.35} r={r * 0.6} fill="#27421d" opacity="0.8" />
          <ellipse cx={x} cy="522" rx={r * 0.9} ry="9" fill="#ffbd6e" opacity="0.28" />
        </g>
      ))}

      {/* the gold light path through the nine chapters */}
      <path
        d={`M${nodes.map(([x, y]) => `${x} ${y}`).join(' L')}`}
        fill="none"
        stroke="#c9a45c"
        strokeWidth="2"
        strokeOpacity="0.9"
        strokeLinejoin="round"
      />
      {nodes.map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="9" fill="none" stroke="#c9a45c" strokeOpacity="0.45" />
          <circle cx={x} cy={y} r="3.5" fill="#f1dfae" />
        </g>
      ))}
    </svg>
  )
}
