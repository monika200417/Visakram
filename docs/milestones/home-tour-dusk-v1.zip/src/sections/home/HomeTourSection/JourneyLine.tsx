import { homeTourChapters } from '../../../data/homeTour'
import { tour } from '../../../three/home-tour/cameraPath'
import styles from './HomeTourSection.module.css'

/**
 * The reference's gold light path, reinterpreted as an architectural
 * surveying line: a fine rail, a trace drawn along it as the camera
 * advances, a station tick at each of the nine chapters (spaced by where the
 * camera really reaches them, not evenly), and a survey marker at the
 * current position. Purely decorative (aria-hidden); every value is driven
 * by the `--tour-p` CSS variable the scroll hook writes, so it costs nothing
 * per frame in React.
 */
export function JourneyLine() {
  return (
    <div className={styles.journey} aria-hidden="true">
      <div className={styles.rail} />
      <div className={styles.trace} />
      <ol className={styles.stations}>
        {homeTourChapters.map((chapter, i) => (
          <li
            key={chapter.id}
            className={styles.station}
            style={{ left: `${(tour.anchors[i] ?? 0) * 100}%` }}
            data-tour-node
            data-active={i === 0}
          >
            <span className={styles.stationNo}>{chapter.index}</span>
          </li>
        ))}
      </ol>
      <div className={styles.marker}>
        <span className={styles.markerRing} />
        <span className={styles.markerDot} />
      </div>
    </div>
  )
}
