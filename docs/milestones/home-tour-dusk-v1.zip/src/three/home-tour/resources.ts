import { useEffect, useMemo } from 'react'
import { useLoader } from '@react-three/fiber'
import * as THREE from 'three'
import { mergeZone, type ZoneGeometries } from './geometry'
import { STAIR_RUN, parts, type MatKey, type ZoneId } from './layout'

const TEXTURE_URLS = [
  '/assets/images/home-tour/ht-stone.webp',
  '/assets/images/home-tour/ht-travertine.webp',
  '/assets/images/home-tour/ht-oak.webp',
  '/assets/images/home-tour/ht-paving.webp',
] as const

export const mergedZones: readonly ZoneId[] = [
  'site',
  'shell',
  'hall',
  'living',
  'dining',
  'kitchen',
  'stair',
  'bedroom',
  'balcony',
  'terrace',
]

export type TourResources = {
  materials: Record<MatKey, THREE.Material> & {
    leaf: THREE.MeshStandardMaterial
    trunk: THREE.MeshStandardMaterial
    halo: THREE.MeshBasicMaterial
    sky: THREE.MeshBasicMaterial
    city: THREE.MeshBasicMaterial
  }
  zones: Record<ZoneId, ZoneGeometries>
  haloTexture: THREE.Texture
}

function radialGradientTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')!
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  g.addColorStop(0, 'rgba(255,214,150,1)')
  g.addColorStop(0.35, 'rgba(255,170,90,0.45)')
  g.addColorStop(1, 'rgba(255,140,60,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 64, 64)
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
}

/**
 * Builds — once — every texture, material and merged zone geometry the tour
 * needs, and disposes all of it when the experience unmounts. Materials are
 * shared across the whole scene (no per-mesh copies), which keeps the GPU
 * state small and lets the zone meshes batch.
 */
export function useTourResources(): TourResources {
  const textures = useLoader(THREE.TextureLoader, [...TEXTURE_URLS])

  const resources = useMemo<TourResources>(() => {
    const [stone, travertine, oak, paving] = textures as [
      THREE.Texture,
      THREE.Texture,
      THREE.Texture,
      THREE.Texture,
    ]
    for (const t of [stone, travertine, oak, paving]) {
      t.wrapS = THREE.RepeatWrapping
      t.wrapT = THREE.RepeatWrapping
      t.colorSpace = THREE.SRGBColorSpace
      t.anisotropy = 4
    }

    const std = (p: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(p)
    const materials = {
      stoneDark: std({ map: stone, roughness: 0.34, metalness: 0.05, envMapIntensity: 1.1 }),
      travertine: std({ map: travertine, roughness: 0.8 }),
      concrete: std({ color: 0x77736a, roughness: 0.92 }),
      oak: std({ map: oak, roughness: 0.55 }),
      blackMetal: std({ color: 0x0c0c0d, roughness: 0.38, metalness: 0.85 }),
      glass: std({
        color: 0xb9c4cc,
        roughness: 0.05,
        metalness: 0.1,
        transparent: true,
        opacity: 0.2,
        depthWrite: false,
        side: THREE.DoubleSide,
        envMapIntensity: 1.6,
      }),
      plaster: std({ color: 0xcdc3b2, roughness: 0.95 }),
      floorStone: std({ map: travertine, color: 0xc2b7a3, roughness: 0.42 }),
      floorOak: std({ map: oak, color: 0xd8c3a4, roughness: 0.5 }),
      fabric: std({ color: 0xb6aa98, roughness: 0.96 }),
      fabricDark: std({ color: 0x2b2622, roughness: 0.95 }),
      linen: std({ color: 0xe6dccb, roughness: 0.95 }),
      counter: std({ map: stone, roughness: 0.28, metalness: 0.05 }),
      cabinet: std({ color: 0x1e1815, roughness: 0.5, metalness: 0.15 }),
      led: new THREE.MeshBasicMaterial({ color: 0xffc27a, toneMapped: false }),
      paving: std({ map: paving, roughness: 0.26, metalness: 0.1, envMapIntensity: 1.3 }),
      leaf: std({
        color: 0x16301a,
        emissive: 0x2c3d12,
        emissiveIntensity: 0.4,
        roughness: 0.9,
        flatShading: true,
      }),
      trunk: std({ color: 0x2a1d14, roughness: 0.9 }),
      halo: new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
        opacity: 0.38,
      }),
      sky: new THREE.MeshBasicMaterial({
        vertexColors: true,
        side: THREE.BackSide,
        fog: false,
        depthWrite: false,
      }),
      city: new THREE.MeshBasicMaterial({ color: 0xffc27a, fog: false, toneMapped: false }),
    } as TourResources['materials']

    // Repeat the paving texture across the ground: 4 m per tile via uv scale in layout.
    const haloTexture = radialGradientTexture()
    materials.halo.map = haloTexture

    const zones = Object.fromEntries(
      mergedZones.map((zone) => [zone, mergeZone(parts, zone)]),
    ) as TourResources['zones']

    return { materials, zones, haloTexture }
  }, [textures])

  useEffect(
    () => () => {
      for (const material of Object.values(resources.materials)) material.dispose()
      for (const zone of Object.values(resources.zones)) {
        for (const geometry of Object.values(zone)) geometry?.dispose()
      }
      resources.haloTexture.dispose()
      for (const t of textures) t.dispose()
      useLoader.clear(THREE.TextureLoader, [...TEXTURE_URLS])
    },
    [resources, textures],
  )

  return resources
}

/** Shared low-poly shapes for every instanced detail; built once, disposed on unmount. */
export function useShapes() {
  const shapes = useMemo(
    () => ({
      seat: new THREE.BoxGeometry(0.46, 0.05, 0.46),
      back: new THREE.BoxGeometry(0.46, 0.5, 0.04),
      stool: new THREE.CylinderGeometry(0.2, 0.18, 0.66, 10),
      shade: new THREE.CylinderGeometry(0.1, 0.16, 0.42, 12),
      glowDisc: new THREE.CircleGeometry(0.15, 14).rotateX(Math.PI / 2),
      cord: new THREE.BoxGeometry(0.012, 0.8, 0.012),
      downlight: new THREE.CircleGeometry(0.085, 12).rotateX(Math.PI / 2),
      tread: new THREE.BoxGeometry(1.3, 0.07, STAIR_RUN + 0.05),
      treadLed: new THREE.BoxGeometry(1.3, 0.025, 0.02),
      trunk: new THREE.CylinderGeometry(0.12, 0.2, 1, 6),
      canopy: new THREE.IcosahedronGeometry(1, 1),
      shrub: new THREE.IcosahedronGeometry(1, 1),
      pool: new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2),
    }),
    [],
  )
  useEffect(
    () => () => {
      Object.values(shapes).forEach((g) => g.dispose())
    },
    [shapes],
  )
  return shapes
}

export type TourShapes = ReturnType<typeof useShapes>
