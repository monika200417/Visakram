import { stairEyeY } from './stairs'

export type Vec3 = readonly [number, number, number]

/**
 * The camera's route through the residence. The camera never rotates freely
 * and never cuts: it is a predetermined path, and the user's scroll only
 * controls how far along it we are. Each waypoint gives where the camera is,
 * what it looks at, the lens, and how the path behaves there.
 *
 * Progress values are NOT stored here — cameraPath.ts derives them from the
 * actual path length, per-segment speed and dwell, so the timing always
 * reflects the real geometry. Where the view must turn a long way (the
 * hall, the dining turn, the stair landing, the bedroom, the pull-out) the
 * segments are deliberately slower (`speed` < 1), which gives the turn more
 * scroll distance so no single scroll notch swings the view abruptly.
 */
export type Waypoint = {
  id: string
  position: Vec3
  lookAt: Vec3
  fov: number
  /** Marks the anchor of one of the nine chapters (same id as the chapter). */
  chapter?: boolean
  /** Hold time (in path-seconds) the camera lingers here. Chapters dwell. */
  dwell?: number
  /** Speed multiplier for the segment arriving at this waypoint (default 1). */
  speed?: number
}

const stairRiseZ = -1.2
const stairLandingZ = -3.9

export const waypoints: readonly Waypoint[] = [
  // 01 EXTERIOR — the opening composition: the whole house at dusk
  {
    id: 'exterior',
    chapter: true,
    position: [-12.0, 2.7, 34.0],
    lookAt: [0.6, 3.4, 1.0],
    fov: 32,
    dwell: 4,
  },
  { id: 'approachA', position: [-5.0, 1.9, 17.5], lookAt: [0.3, 2.9, 3.5], fov: 40, speed: 2.2 },
  { id: 'approachB', position: [-0.3, 1.8, 9.4], lookAt: [0, 2.7, 3.5], fov: 42, speed: 1.6 },
  // 02 ENTRY — the threshold; the door opens as we arrive
  {
    id: 'entry',
    chapter: true,
    position: [0, 2.05, 6.1],
    lookAt: [0, 2.35, 2.0],
    fov: 46,
    dwell: 3,
    speed: 1.4,
  },
  { id: 'threshold', position: [0, 2.05, 3.2], lookAt: [0, 2.1, -0.6], fov: 50, speed: 1.2 },
  { id: 'hallExit', position: [-0.4, 2.05, 0.8], lookAt: [-3.4, 1.9, -1.9], fov: 54, speed: 0.65 },
  // 03 LIVING
  {
    id: 'living',
    chapter: true,
    position: [-3.1, 2.05, -0.5],
    lookAt: [-6.0, 1.6, -3.3],
    fov: 56,
    dwell: 3.5,
    speed: 0.9,
  },
  // 04 DINING
  {
    id: 'dining',
    chapter: true,
    position: [-0.7, 2.05, -0.2],
    lookAt: [0.6, 1.6, -3.0],
    fov: 54,
    dwell: 3,
    speed: 0.44,
  },
  {
    id: 'kitchenApproach',
    position: [2.4, 2.05, 0.2],
    lookAt: [4.4, 1.5, -2.4],
    fov: 54,
    speed: 1.0,
  },
  // 05 KITCHEN
  {
    id: 'kitchen',
    chapter: true,
    position: [3.3, 2.05, 1.6],
    lookAt: [4.6, 1.4, -2.8],
    fov: 54,
    dwell: 3,
    speed: 1.2,
  },
  {
    id: 'stairApproach',
    position: [5.6, 2.05, 1.5],
    lookAt: [7.1, 2.6, -1.5],
    fov: 54,
    speed: 0.8,
  },
  // 06 STAIRCASE — seen from its foot, then climbed
  {
    id: 'staircase',
    chapter: true,
    position: [7.15, 2.05, 1.7],
    lookAt: [7.15, 3.9, -3.4],
    fov: 56,
    dwell: 3.2,
    speed: 0.9,
  },
  {
    id: 'stairRise',
    position: [7.15, stairEyeY(stairRiseZ), stairRiseZ],
    lookAt: [6.9, stairEyeY(stairRiseZ) + 1.2, -4.4],
    fov: 54,
    speed: 1.5,
  },
  {
    id: 'stairLanding',
    position: [7.15, stairEyeY(stairLandingZ), stairLandingZ],
    lookAt: [5.9, 5.3, -4.7],
    fov: 54,
    speed: 0.6,
  },
  { id: 'stairTop', position: [7.05, 5.75, -4.75], lookAt: [4.2, 5.2, -4.2], fov: 54, speed: 0.4 },
  // 07 BEDROOM
  {
    id: 'bedroom',
    chapter: true,
    position: [5.6, 5.75, -2.2],
    lookAt: [2.0, 5.0, -2.2],
    fov: 52,
    dwell: 3.5,
    speed: 0.9,
  },
  {
    id: 'bedroomSweep',
    position: [5.2, 5.75, -1.0],
    lookAt: [2.4, 5.3, -0.4],
    fov: 52,
    speed: 0.52,
  },
  {
    id: 'bedroomTurn',
    position: [4.9, 5.75, 0.1],
    lookAt: [3.0, 5.3, 2.6],
    fov: 52,
    speed: 0.48,
  },
  // The sliding glass opens between here and the balcony
  {
    id: 'balconyApproach',
    position: [4.8, 5.75, 1.2],
    lookAt: [4.8, 5.3, 6.5],
    fov: 54,
    speed: 0.5,
  },
  // 08 BALCONY
  {
    id: 'balcony',
    chapter: true,
    position: [4.8, 5.75, 2.9],
    lookAt: [4.4, 4.6, 9.0],
    fov: 52,
    dwell: 3.5,
    speed: 1.3,
  },
  // Through the opening, over the rail, then a long swing back toward the house
  { id: 'passThrough', position: [4.8, 6.05, 7.4], lookAt: [2.0, 4.0, 12.0], fov: 48, speed: 1.5 },
  { id: 'swingA', position: [3.2, 5.6, 11.2], lookAt: [-3.5, 3.6, 9.0], fov: 46, speed: 0.9 },
  { id: 'swingB', position: [-1.2, 4.6, 17.0], lookAt: [-6.0, 3.4, 4.0], fov: 42, speed: 1.5 },
  // 09 EXTERIOR REVEAL — back where we began: the same house, one composition
  {
    id: 'reveal',
    chapter: true,
    position: [-12.8, 3.0, 35.0],
    lookAt: [0.6, 3.4, 1.0],
    fov: 32,
    dwell: 4,
    speed: 1.6,
  },
]
