/**
 * Floor levels and the stair — the few constants the camera path needs. Kept
 * apart from layout.ts (which holds every wall and piece of furniture) so the
 * main bundle, which only needs the camera timing, never pulls in the house.
 */
// ---------------------------------------------------------------- levels
export const FL0 = 0.45 // ground-floor finished level
export const CEIL0 = 3.75 // underside of the first-floor slab
export const SLAB = 0.4
export const FL1 = CEIL0 + SLAB // 4.15 — first-floor finished level
export const CEIL1 = 7.15 // underside of the roof
export const ROOF_TOP = CEIL1 + 0.35
export const EYE = 1.6

// ---------------------------------------------------------------- stair
export const STAIR_X0 = 6.5
export const STAIR_X1 = 7.8
export const STAIR_CX = (STAIR_X0 + STAIR_X1) / 2
export const STAIR_Z_START = 0.4 // first riser
export const STAIR_Z_END = -4.9 // top nosing
export const STAIR_STEPS = 22
export const STAIR_RISE = (FL1 - FL0) / STAIR_STEPS
export const STAIR_RUN = (STAIR_Z_START - STAIR_Z_END) / STAIR_STEPS

/** Camera eye height while on the stair at depth z (smooth, linear between treads). */
export function stairEyeY(z: number): number {
  const t = Math.min(STAIR_STEPS, Math.max(0, (STAIR_Z_START - z) / STAIR_RUN))
  return FL0 + STAIR_RISE * t + EYE
}

/** Centre z and top y of tread i (0 = lowest). */
export function stairTread(i: number): { z: number; top: number } {
  return { z: STAIR_Z_START - (i + 0.5) * STAIR_RUN, top: FL0 + (i + 1) * STAIR_RISE }
}
