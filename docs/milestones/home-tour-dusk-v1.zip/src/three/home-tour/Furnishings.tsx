import { useLayoutEffect, useRef } from 'react'
import * as THREE from 'three'
import { setInstances } from './geometry'
import {
  FL0,
  FL1,
  STAIR_CX,
  STAIR_RISE,
  STAIR_RUN,
  STAIR_STEPS,
  chairs,
  downlights,
  pendants,
  shrubs,
  stairTread,
  stools,
  trees,
} from './layout'
import type { TourResources, TourShapes } from './resources'

type Instance = {
  position: readonly [number, number, number]
  yaw?: number
  scale?: readonly [number, number, number]
}

/** One InstancedMesh drawn in a single call (see setInstances). */
function InstancedGroup({
  geometry,
  material,
  items,
}: {
  geometry: THREE.BufferGeometry
  material: THREE.Material
  items: readonly Instance[]
}) {
  const ref = useRef<THREE.InstancedMesh>(null)
  useLayoutEffect(() => {
    if (ref.current) setInstances(ref.current, items)
  }, [items])
  return <instancedMesh ref={ref} args={[geometry, material, items.length]} frustumCulled={false} />
}

// ----------------------------------------------------------- static instance lists
const chairItems = chairs.map((c) => ({ position: [c.x, FL0 + 0.46, c.z] as const, yaw: c.a }))
const chairBackItems = chairs.map((c) => ({
  position: [c.x - 0.21 * Math.sin(c.a), FL0 + 0.73, c.z - 0.21 * Math.cos(c.a)] as const,
  yaw: c.a,
}))
const stoolItems = stools.map((s) => ({ position: [s.x, FL0 + 0.33, s.z] as const }))
const pendantShadeItems = pendants.map((p) => ({ position: [p.x, 3.0, p.z] as const }))
const pendantGlowItems = pendants.map((p) => ({ position: [p.x, 2.79, p.z] as const }))
const pendantCordItems = pendants.map((p) => ({ position: [p.x, 3.62, p.z] as const }))
const downlightItems = downlights.map((d) => ({ position: [d[0], d[1] - 0.005, d[2]] as const }))
const treadItems = Array.from({ length: STAIR_STEPS }, (_, i) => {
  const { z, top } = stairTread(i)
  return { position: [STAIR_CX, top - 0.035, z] as const }
})
const treadLedItems = Array.from({ length: STAIR_STEPS }, (_, i) => {
  const { z, top } = stairTread(i)
  return { position: [STAIR_CX, top - 0.095, z + STAIR_RUN / 2 + 0.005] as const }
})
const trunkItems = trees.map((t) => ({
  position: [t.x, t.h / 2, t.z] as const,
  scale: [1, t.h, 1] as const,
}))
const canopyItems = trees.map((t) => ({
  position: [t.x, t.h + 0.3, t.z] as const,
  scale: [t.r * 1.15, t.r * 0.95, t.r * 1.15] as const,
}))
const shrubItems = shrubs.map((s) => ({
  position: [s.x, s.y + s.r * 0.5, s.z] as const,
  scale: [s.r, s.r * 0.75, s.r] as const,
}))
const poolItems = [
  // Uplight pools at the base of each tree, and the warm spill from the portico and glazing
  ...trees.map((t) => ({
    position: [t.x, 0.03, t.z] as const,
    scale: [t.r * 3, 1, t.r * 3] as const,
  })),
  { position: [0, 0.03, 9.2] as const, scale: [12, 1, 7.5] as const },
  { position: [5.2, 0.03, 6.4] as const, scale: [8, 1, 3.2] as const },
]

/** Dining chairs, pendants and kitchen stools (the dining/kitchen zones render these). */
export function DiningDetail({ resources, s }: { resources: TourResources; s: TourShapes }) {
  const m = resources.materials
  return (
    <>
      <InstancedGroup geometry={s.seat} material={m.fabricDark} items={chairItems} />
      <InstancedGroup geometry={s.back} material={m.oak} items={chairBackItems} />
      <InstancedGroup geometry={s.cord} material={m.blackMetal} items={pendantCordItems} />
      <InstancedGroup geometry={s.shade} material={m.blackMetal} items={pendantShadeItems} />
      <InstancedGroup geometry={s.glowDisc} material={m.led} items={pendantGlowItems} />
    </>
  )
}

export function KitchenDetail({ resources, s }: { resources: TourResources; s: TourShapes }) {
  return (
    <InstancedGroup
      geometry={s.stool}
      material={resources.materials.fabricDark}
      items={stoolItems}
    />
  )
}

/** The floating stair: treads with a warm light under every nosing. */
export function StairDetail({ resources, s }: { resources: TourResources; s: TourShapes }) {
  const m = resources.materials
  const angle = Math.atan2(STAIR_RISE, STAIR_RUN)
  const run = 0.4 - -3.8
  const length = run / Math.cos(angle)
  const midZ = (0.4 + -3.8) / 2
  const topAt = (z: number) => FL0 + ((0.4 - z) / STAIR_RUN) * STAIR_RISE
  return (
    <>
      <InstancedGroup geometry={s.tread} material={m.cabinet} items={treadItems} />
      <InstancedGroup geometry={s.treadLed} material={m.led} items={treadLedItems} />
      {/* inclined glass balustrade + black handrail */}
      <mesh position={[6.42, topAt(midZ) + 0.45, midZ]} rotation={[angle, 0, 0]} material={m.glass}>
        <boxGeometry args={[0.03, 0.9, length]} />
      </mesh>
      <mesh
        position={[6.42, topAt(midZ) + 0.92, midZ]}
        rotation={[angle, 0, 0]}
        material={m.blackMetal}
      >
        <boxGeometry args={[0.05, 0.04, length]} />
      </mesh>
      {/* the landing rail along the stair void upstairs */}
      <mesh position={[6.4, FL1 + 0.55, -1.25]} material={m.glass}>
        <boxGeometry args={[0.03, 1.0, 4.1]} />
      </mesh>
      <mesh position={[6.4, FL1 + 1.07, -1.25]} material={m.blackMetal}>
        <boxGeometry args={[0.05, 0.04, 4.1]} />
      </mesh>
    </>
  )
}

/** Recessed downlights — a warm disc on every ceiling and the portico soffit. */
export function Downlights({ resources, s }: { resources: TourResources; s: TourShapes }) {
  return (
    <InstancedGroup
      geometry={s.downlight}
      material={resources.materials.led}
      items={downlightItems}
    />
  )
}

/** Uplit trees, shrubs and the warm pools of light on the wet paving. Always drawn. */
export function Landscape({ resources, s }: { resources: TourResources; s: TourShapes }) {
  const m = resources.materials
  return (
    <>
      <InstancedGroup geometry={s.trunk} material={m.trunk} items={trunkItems} />
      <InstancedGroup geometry={s.canopy} material={m.leaf} items={canopyItems} />
      <InstancedGroup geometry={s.shrub} material={m.leaf} items={shrubItems} />
      <InstancedGroup geometry={s.pool} material={m.halo} items={poolItems} />
    </>
  )
}
