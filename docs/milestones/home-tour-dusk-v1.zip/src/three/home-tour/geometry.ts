import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import type { MatKey, Part, ZoneId } from './layout'

/**
 * A box at centre `c` with size `s`, positioned in world space, whose UVs are
 * scaled by each face's real size so a texture tiles at `uv` metres no matter
 * how the part is proportioned (long walls, thin slabs and so on). Merging
 * these per material keeps the whole house to a few dozen draw calls.
 */
export function boxGeometry(
  c: readonly [number, number, number],
  s: readonly [number, number, number],
  uv = 2,
): THREE.BufferGeometry {
  const geometry = new THREE.BoxGeometry(s[0], s[1], s[2])
  const uvs = geometry.getAttribute('uv') as THREE.BufferAttribute
  // BoxGeometry face order: +x, −x, +y, −y, +z, −z (4 vertices each)
  const faceSize: ReadonlyArray<readonly [number, number]> = [
    [s[2], s[1]],
    [s[2], s[1]],
    [s[0], s[2]],
    [s[0], s[2]],
    [s[0], s[1]],
    [s[0], s[1]],
  ]
  for (let face = 0; face < 6; face++) {
    const [w, h] = faceSize[face]!
    for (let v = 0; v < 4; v++) {
      const i = face * 4 + v
      uvs.setXY(i, (uvs.getX(i) * w) / uv, (uvs.getY(i) * h) / uv)
    }
  }
  geometry.translate(c[0], c[1], c[2])
  return geometry
}

export type ZoneGeometries = Partial<Record<MatKey, THREE.BufferGeometry>>

/** Merges every part of a zone into one geometry per material. */
export function mergeZone(parts: readonly Part[], zone: ZoneId): ZoneGeometries {
  const byMaterial = new Map<MatKey, THREE.BufferGeometry[]>()
  for (const part of parts) {
    if (part.zone !== zone) continue
    const list = byMaterial.get(part.mat) ?? []
    list.push(boxGeometry(part.c, part.s, part.uv))
    byMaterial.set(part.mat, list)
  }
  const result: ZoneGeometries = {}
  for (const [mat, list] of byMaterial) {
    const merged = mergeGeometries(list, false)
    list.forEach((g) => g.dispose())
    if (merged) result[mat] = merged
  }
  return result
}

/** Writes instance matrices (position, yaw, scale) into an InstancedMesh. */
export function setInstances(
  mesh: THREE.InstancedMesh,
  items: ReadonlyArray<{
    position: readonly [number, number, number]
    yaw?: number
    scale?: readonly [number, number, number]
  }>,
) {
  const dummy = new THREE.Object3D()
  items.forEach((item, i) => {
    dummy.position.set(item.position[0], item.position[1], item.position[2])
    dummy.rotation.set(0, item.yaw ?? 0, 0)
    const s = item.scale ?? [1, 1, 1]
    dummy.scale.set(s[0], s[1], s[2])
    dummy.updateMatrix()
    mesh.setMatrixAt(i, dummy.matrix)
  })
  mesh.count = items.length
  mesh.instanceMatrix.needsUpdate = true
  mesh.computeBoundingSphere()
}
