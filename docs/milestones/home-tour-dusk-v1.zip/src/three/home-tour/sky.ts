import * as THREE from 'three'

/**
 * Procedural dusk, built from vertex colours — no HDRI, no texture. A near-
 * black zenith falls to a warm orange horizon that is strongest toward +X
 * (the same side the opening exterior's glow sits), over a dark ground-level
 * haze that matches the scene fog so the ground melts into the horizon.
 */
export const FOG_COLOR = 0x1a120d
export const GLOW_DIRECTION = new THREE.Vector3(0.8, 0, 0.45).normalize()

export function createSkyGeometry(): THREE.SphereGeometry {
  const geometry = new THREE.SphereGeometry(180, 36, 24)
  const position = geometry.getAttribute('position')
  const colors = new Float32Array(position.count * 3)

  const zenith = new THREE.Color(0x04060d)
  const upper = new THREE.Color(0x151126)
  const horizon = new THREE.Color(0x8a3d1f)
  const glow = new THREE.Color(0xff8a3a)
  const haze = new THREE.Color(FOG_COLOR)
  const c = new THREE.Color()
  const d = new THREE.Vector3()

  for (let i = 0; i < position.count; i++) {
    d.set(position.getX(i), position.getY(i), position.getZ(i)).normalize()
    const y = d.y
    if (y <= 0) {
      c.copy(horizon).lerp(haze, Math.min(1, -y / 0.12 + 0.55))
    } else {
      c.copy(horizon).lerp(upper, Math.min(1, y / 0.22))
      c.lerp(zenith, Math.min(1, Math.max(0, (y - 0.1) / 0.55)))
      const toGlow = Math.max(0, d.x * GLOW_DIRECTION.x + d.z * GLOW_DIRECTION.z) ** 4
      const strength = toGlow * Math.exp(-y * 6.5)
      c.r += glow.r * strength * 0.95
      c.g += glow.g * strength * 0.95
      c.b += glow.b * strength * 0.95
    }
    colors[i * 3] = c.r
    colors[i * 3 + 1] = c.g
    colors[i * 3 + 2] = c.b
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
  return geometry
}

/** A ring of dark ridgelines (a strip around the horizon) with a faint warm rim toward the glow. */
export function createMountainRing(
  radius: number,
  base: number,
  amplitude: number,
  seed: number,
  body: number,
): THREE.BufferGeometry {
  const segments = 120
  const positions: number[] = []
  const colors: number[] = []
  const indices: number[] = []
  const dark = new THREE.Color(body)
  const rim = new THREE.Color(0x4a2a1a)
  const c = new THREE.Color()

  for (let i = 0; i <= segments; i++) {
    const a = (i / segments) * Math.PI * 2
    const h =
      base +
      amplitude *
        (0.55 * Math.sin(3 * a + seed) +
          0.3 * Math.sin(7 * a + 2 * seed) +
          0.15 * Math.sin(17 * a)) +
      amplitude * 0.5
    const x = Math.cos(a) * radius
    const z = Math.sin(a) * radius
    positions.push(x, -4, z, x, Math.max(0.8, h), z)
    const facing = Math.max(0, Math.cos(a) * GLOW_DIRECTION.x + Math.sin(a) * GLOW_DIRECTION.z) ** 2
    c.copy(dark)
    colors.push(dark.r, dark.g, dark.b)
    c.copy(dark).lerp(rim, facing * 0.75)
    colors.push(c.r, c.g, c.b)
    if (i < segments) {
      const k = i * 2
      indices.push(k, k + 1, k + 2, k + 1, k + 3, k + 2)
    }
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
  geometry.setIndex(indices)
  return geometry
}

/** Deterministic distant "town" lights, scattered low toward the glow side. */
export function cityLightItems(count = 90) {
  let seed = 7
  const rand = () => {
    seed = (seed * 16807) % 2147483647
    return seed / 2147483647
  }
  const centre = Math.atan2(GLOW_DIRECTION.z, GLOW_DIRECTION.x)
  return Array.from({ length: count }, () => {
    const a = centre + (rand() - 0.5) * Math.PI * 1.4
    const r = 76 + rand() * 14
    const x = Math.cos(a) * r
    const z = Math.sin(a) * r
    return {
      position: [x, 0.4 + rand() * 3.4, z] as const,
      yaw: Math.atan2(-x, -z),
      scale: [0.5 + rand() * 0.7, 0.5 + rand() * 0.7, 1] as const,
    }
  })
}
