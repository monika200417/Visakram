import { useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import type * as THREE from 'three'
import { tour } from './cameraPath'
import { POOL_SIZE, pooledLights } from './choreography'
import { smoothstep } from './pathMath'

type ProgressRef = RefObject<{ value: number }>

const A = tour.arrivalProgress
const ramp = (from: number, to: number, p: number) => smoothstep((p - from) / (to - from))

/**
 * Warm dusk lighting with a deliberately small, fixed light count: a
 * hemisphere + a no-shadow "horizon" directional, THREE pooled warm point
 * lights that travel from space to space (see choreography.ts), and one soft
 * fill that follows the camera indoors. No shadow maps, no light is ever
 * added or removed during the journey (that would force shader recompiles).
 */
export function LightRig({ progressRef }: { progressRef: ProgressRef }) {
  const pool = useRef<Array<THREE.PointLight | null>>([])
  const fill = useRef<THREE.PointLight>(null)

  useFrame(({ camera }) => {
    const p = progressRef.current.value
    const lights = pooledLights(p)
    for (let i = 0; i < POOL_SIZE; i++) {
      const light = pool.current[i]
      const target = lights[i]
      if (!light || !target) continue
      light.position.set(target.position[0], target.position[1], target.position[2])
      light.intensity = target.intensity
    }
    if (fill.current) {
      // Indoors from the threshold to the balcony; fades in and out with progress.
      const indoors =
        ramp(A.threshold! - 0.03, A.threshold! + 0.01, p) *
        (1 - ramp(A.balcony!, A.passThrough!, p))
      fill.current.intensity = 9 * indoors
      fill.current.position.set(camera.position.x, camera.position.y + 0.4, camera.position.z)
    }
  })

  return (
    <>
      <hemisphereLight args={[0x7a5442, 0x16110d, 0.95]} />
      <directionalLight color={0xff9a55} intensity={0.55} position={[30, 6, 12]} />
      {Array.from({ length: POOL_SIZE }, (_, i) => (
        <pointLight
          key={i}
          ref={(node) => {
            pool.current[i] = node
          }}
          color={0xffbd7a}
          intensity={0}
          distance={16}
          decay={2}
        />
      ))}
      <pointLight ref={fill} color={0xffc58a} intensity={0} distance={10} decay={2} />
    </>
  )
}
