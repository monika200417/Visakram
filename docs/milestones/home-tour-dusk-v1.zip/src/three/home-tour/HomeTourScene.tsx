import { useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { tour } from './cameraPath'
import { doorOpen, glassOpen } from './choreography'
import { TourEnvironment } from './Environment'
import { DiningDetail, Downlights, KitchenDetail, Landscape, StairDetail } from './Furnishings'
import { CEIL1, FL0, FL1, regionAt, type Region, type ZoneId } from './layout'
import { LightRig } from './LightRig'
import { mergedZones, useShapes, useTourResources } from './resources'

export type ProgressRef = RefObject<{ value: number }>

/**
 * Zones that cannot be seen from a given part of the house, and so are not
 * drawn there. Nothing is mounted or unmounted during the journey — only
 * `visible` is toggled, and only on things hidden behind the first-floor slab
 * or the walls — so there is no visible pop-in. From outside, everything is
 * drawn (the interior is visible through the glass at both ends).
 */
const hiddenIn: Record<Region, readonly ZoneId[]> = {
  exterior: [],
  ground: ['bedroom', 'balcony', 'terrace'],
  upper: ['hall', 'living', 'dining', 'kitchen'],
}

const DOOR_HINGE = [-0.7, FL0, 4.0] as const
const GLASS_H = CEIL1 - FL1 - 0.2

/**
 * ONE house, ONE camera. Everything responds to a single normalized
 * progress value (`progressRef`, written by the scrubbed GSAP timeline in
 * useHomeTourScrub): the camera pose is sampled from the predetermined path,
 * and the door, the balcony glass, the travelling lights and zone visibility
 * all read the same value inside useFrame. No React state changes while
 * scrolling.
 */
export function HomeTourScene({ progressRef }: { progressRef: ProgressRef }) {
  const resources = useTourResources()
  const shapes = useShapes()

  const zoneGroups = useRef<Partial<Record<ZoneId, THREE.Group | null>>>({})
  const lastRegion = useRef<Region | null>(null)
  const door = useRef<THREE.Group>(null)
  const glassA = useRef<THREE.Group>(null)
  const glassB = useRef<THREE.Group>(null)

  useFrame((state) => {
    const camera = state.camera as THREE.PerspectiveCamera
    const p = progressRef.current.value
    const sample = tour.sample(p)
    camera.position.set(sample.position[0], sample.position[1], sample.position[2])
    camera.lookAt(sample.lookAt[0], sample.lookAt[1], sample.lookAt[2])
    if (Math.abs(camera.fov - sample.fov) > 1e-3) {
      camera.fov = sample.fov
      camera.updateProjectionMatrix()
    }

    const region = regionAt(sample.position[0], sample.position[1], sample.position[2])
    if (region !== lastRegion.current) {
      lastRegion.current = region
      for (const zone of mergedZones) {
        const group = zoneGroups.current[zone]
        if (group) group.visible = !hiddenIn[region].includes(zone)
      }
    }

    if (import.meta.env.DEV) {
      // Dev-only: lets QA read the per-frame render cost against the budget.
      const { render, memory } = state.gl.info
      ;(window as unknown as { __homeTourStats?: unknown }).__homeTourStats = {
        calls: render.calls,
        triangles: render.triangles,
        geometries: memory.geometries,
        textures: memory.textures,
      }
    }

    if (door.current) door.current.rotation.y = doorOpen(p) * Math.PI * 0.5
    const slide = glassOpen(p)
    if (glassA.current) glassA.current.position.x = 4.2 - 1.2 * slide
    if (glassB.current) glassB.current.position.x = 5.4 + 1.2 * slide
  })

  const m = resources.materials

  return (
    <>
      <TourEnvironment resources={resources} />
      <LightRig progressRef={progressRef} />

      {mergedZones.map((zone) => (
        <group
          key={zone}
          ref={(node) => {
            zoneGroups.current[zone] = node
          }}
        >
          {(
            Object.entries(resources.zones[zone]) as Array<[keyof typeof m, THREE.BufferGeometry]>
          ).map(([mat, geometry]) => (
            <mesh key={mat} geometry={geometry} material={m[mat]} />
          ))}
          {zone === 'dining' ? <DiningDetail resources={resources} s={shapes} /> : null}
          {zone === 'kitchen' ? <KitchenDetail resources={resources} s={shapes} /> : null}
          {zone === 'stair' ? <StairDetail resources={resources} s={shapes} /> : null}
        </group>
      ))}

      <Landscape resources={resources} s={shapes} />
      <Downlights resources={resources} s={shapes} />

      {/* The front door: a tall timber leaf hinged at the left jamb, opening inward */}
      <group ref={door} position={[DOOR_HINGE[0], DOOR_HINGE[1], DOOR_HINGE[2]]}>
        <mesh position={[0.7, 1.5, 0]} material={m.oak}>
          <boxGeometry args={[1.4, 3.0, 0.07]} />
        </mesh>
        <mesh position={[1.25, 1.1, 0.06]} material={m.blackMetal}>
          <boxGeometry args={[0.03, 0.32, 0.05]} />
        </mesh>
      </group>

      {/* The balcony's sliding glass: two panes that part toward the jambs */}
      {(
        [
          { ref: glassA, x: 4.2 },
          { ref: glassB, x: 5.4 },
        ] as const
      ).map(({ ref, x }) => (
        <group key={x} ref={ref} position={[x, FL1 + 0.1 + GLASS_H / 2, 1.95]}>
          <mesh material={m.glass}>
            <boxGeometry args={[1.2, GLASS_H, 0.03]} />
          </mesh>
          <mesh position={[-0.59, 0, 0]} material={m.blackMetal}>
            <boxGeometry args={[0.04, GLASS_H, 0.05]} />
          </mesh>
          <mesh position={[0.59, 0, 0]} material={m.blackMetal}>
            <boxGeometry args={[0.04, GLASS_H, 0.05]} />
          </mesh>
        </group>
      ))}
    </>
  )
}
