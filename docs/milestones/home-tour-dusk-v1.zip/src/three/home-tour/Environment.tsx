import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import { setInstances } from './geometry'
import { cityLightItems, createMountainRing, createSkyGeometry, FOG_COLOR } from './sky'
import type { TourResources } from './resources'

/**
 * The dusk world around the house: sky dome, two dark ridgelines, distant
 * town lights, scene fog, and a tiny procedural room environment for
 * reflections on the glass, metal and wet paving. Nothing here loads a file.
 */
export function TourEnvironment({ resources }: { resources: TourResources }) {
  const gl = useThree((state) => state.gl)

  const sky = useMemo(() => createSkyGeometry(), [])
  const far = useMemo(() => createMountainRing(105, 7, 8, 1.3, 0x1c1620), [])
  const near = useMemo(() => createMountainRing(92, 4, 5, 4.1, 0x0d0b0e), [])
  const ridge = useMemo(
    () => new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide, fog: false }),
    [],
  )
  const cityGeometry = useMemo(() => new THREE.PlaneGeometry(1, 1), [])
  const cityItems = useMemo(() => cityLightItems(), [])
  const cityRef = useRef<THREE.InstancedMesh>(null)

  useLayoutEffect(() => {
    if (cityRef.current) setInstances(cityRef.current, cityItems)
  }, [cityItems])

  // A tiny procedural room environment for reflections on glass, metal and wet paving.
  const environment = useMemo(() => {
    const pmrem = new THREE.PMREMGenerator(gl)
    const target = pmrem.fromScene(new RoomEnvironment(), 0.04)
    pmrem.dispose()
    return target
  }, [gl])
  useEffect(() => () => environment.dispose(), [environment])

  useFrame(({ scene }) => {
    if (scene.environmentIntensity !== 0.32) scene.environmentIntensity = 0.32
  })

  useEffect(
    () => () => {
      sky.dispose()
      far.dispose()
      near.dispose()
      ridge.dispose()
      cityGeometry.dispose()
    },
    [sky, far, near, ridge, cityGeometry],
  )

  return (
    <>
      <color attach="background" args={[FOG_COLOR]} />
      <fogExp2 attach="fog" args={[FOG_COLOR, 0.016]} />
      <primitive object={environment.texture} attach="environment" />
      <mesh
        geometry={sky}
        material={resources.materials.sky}
        renderOrder={-10}
        frustumCulled={false}
      />
      <mesh geometry={far} material={ridge} frustumCulled={false} />
      <mesh geometry={near} material={ridge} frustumCulled={false} />
      <instancedMesh
        ref={cityRef}
        args={[cityGeometry, resources.materials.city, cityItems.length]}
        frustumCulled={false}
      />
    </>
  )
}
