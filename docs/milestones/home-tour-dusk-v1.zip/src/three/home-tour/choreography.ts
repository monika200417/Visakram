import { tour } from './cameraPath'
import { smoothstep } from './pathMath'
import type { Vec3 } from './layout'

/**
 * Everything in the scene that responds to the tour, as pure functions of
 * normalized progress. The scene reads these inside useFrame; keeping them
 * here (no three.js) means they are cheap to unit-test and the main bundle
 * never needs the 3D chunk to reason about them.
 */
const A = tour.arrivalProgress
/** Centre of a chapter's dwell (or, for a non-chapter waypoint, its arrival). */
const at = (id: string): number => {
  const chapter = tour.chapterIds.indexOf(id)
  return chapter >= 0 ? tour.anchors[chapter]! : A[id]!
}

const between = (from: number, to: number, p: number) => smoothstep((p - from) / (to - from))

/** 0 = closed, 1 = fully open — the front door opens as the camera approaches the entry. */
export const doorOpen = (p: number): number => between(A.approachA!, A.entry!, p)

/** 0 = closed, 1 = open — the balcony's sliding glass opens as the bedroom turns toward it. */
export const glassOpen = (p: number): number => between(A.bedroomSweep!, A.balconyApproach!, p)

// ------------------------------------------------------------ light stations
export type LightStation = {
  id: string
  /** Progress at which this station's pool of light is at full strength. */
  progress: number
  position: Vec3
  intensity: number
}

/**
 * Warm pools of light that travel with the journey. Only THREE point lights
 * ever exist: station j is always handled by light (j mod 3). Same-light
 * stations are far apart in progress, so a light only moves to its next
 * station when its intensity is effectively zero — the light count never
 * changes (no shader recompiles) and nothing pops.
 */
export const lightStations: readonly LightStation[] = [
  { id: 'exterior', progress: at('exterior'), position: [-0.5, 3.0, 9.0], intensity: 85 },
  { id: 'entry', progress: at('entry'), position: [0, 3.1, 4.8], intensity: 40 },
  { id: 'living', progress: at('living'), position: [-4.8, 3.2, -1.8], intensity: 40 },
  { id: 'dining', progress: at('dining'), position: [1.2, 3.0, -2.2], intensity: 36 },
  { id: 'kitchen', progress: at('kitchen'), position: [4.3, 3.2, -1.2], intensity: 38 },
  { id: 'staircase', progress: at('staircase'), position: [7.1, 3.4, -0.5], intensity: 30 },
  { id: 'stairTop', progress: at('stairTop'), position: [6.2, 6.4, -3.5], intensity: 32 },
  { id: 'bedroom', progress: at('bedroom'), position: [3.6, 6.6, -2.4], intensity: 38 },
  { id: 'balcony', progress: at('balcony'), position: [5.2, 6.6, 3.8], intensity: 42 },
  { id: 'reveal', progress: at('reveal'), position: [-0.5, 3.0, 9.0], intensity: 85 },
]

export const POOL_SIZE = 3
/**
 * Half-width, in progress, of a station's pool of light. The falloff reaches
 * exactly zero at this distance (not asymptotically), and it is derived from
 * the real spacing: never more than half the closest gap between two stations
 * served by the SAME light — so a light only changes station while it is
 * completely dark, however the camera timing shifts.
 */
const RADIUS = (() => {
  let minGap = Infinity
  for (let m = 0; m < POOL_SIZE; m++) {
    const mine = lightStations.filter((_, j) => j % POOL_SIZE === m).map((st) => st.progress)
    for (let i = 1; i < mine.length; i++) minGap = Math.min(minGap, mine[i]! - mine[i - 1]!)
  }
  return Math.min(0.11, (minGap / 2) * 0.999)
})()

export type PooledLight = { position: Vec3; intensity: number }

/** The three pooled lights at progress p. */
export function pooledLights(p: number): PooledLight[] {
  const lights: PooledLight[] = []
  for (let m = 0; m < POOL_SIZE; m++) {
    let best: LightStation | undefined
    let bestWeight = -1
    lightStations.forEach((station, j) => {
      if (j % POOL_SIZE !== m) return
      const d = (p - station.progress) / RADIUS
      const weight = d * d >= 1 ? 0 : (1 - d * d) ** 2
      if (weight > bestWeight) {
        bestWeight = weight
        best = station
      }
    })
    lights.push({ position: best!.position, intensity: best!.intensity * bestWeight })
  }
  return lights
}
