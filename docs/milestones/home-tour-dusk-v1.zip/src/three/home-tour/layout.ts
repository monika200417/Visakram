/**
 * The Home Tour residence — ONE conceptual two-storey house, defined once
 * as data. Both the 3D scene and the camera-clearance tests read these
 * parts, so the camera path and the walls it must avoid can never drift
 * apart. Pure TypeScript: no three.js import, so it is safe to use from the
 * main bundle (tests, overlay) without pulling the 3D chunk.
 *
 * Coordinates are metres. +X is the house's right, +Y up, +Z toward the
 * street/front (the camera starts out front looking toward −Z). The
 * footprint is roughly 16 × 11 m: an open-plan ground floor (living →
 * dining → kitchen) with the entry hall at the centre front and the stair at
 * the far right; a bedroom volume above the right half with a glazed balcony
 * on the front; a planted stone terrace over the left.
 *
 * Deliberately conceptual and unbranded — no signage anywhere.
 */

import { CEIL0, CEIL1, FL0, FL1, ROOF_TOP } from './stairs'

export type Vec3 = readonly [number, number, number]

export type MatKey =
  | 'stoneDark'
  | 'travertine'
  | 'concrete'
  | 'oak'
  | 'blackMetal'
  | 'glass'
  | 'plaster'
  | 'floorStone'
  | 'floorOak'
  | 'fabric'
  | 'fabricDark'
  | 'linen'
  | 'counter'
  | 'cabinet'
  | 'led'
  | 'paving'

/**
 * Zones group parts for merging and for culling. `shell` is always drawn
 * (the building as seen from outside and through glass). Interior zones are
 * hidden only where they genuinely cannot be seen (see zoneVisibility).
 */
export type ZoneId =
  | 'site'
  | 'shell'
  | 'hall'
  | 'living'
  | 'dining'
  | 'kitchen'
  | 'stair'
  | 'bedroom'
  | 'balcony'
  | 'terrace'

export type Part = {
  zone: ZoneId
  mat: MatKey
  /** Centre and size (metres). */
  c: Vec3
  s: Vec3
  /** Counts as an obstacle for camera-clearance checks. */
  solid?: boolean
  /** Texture tile size in metres (UV scale). */
  uv?: number
}

export {
  CEIL0,
  CEIL1,
  EYE,
  FL0,
  FL1,
  ROOF_TOP,
  SLAB,
  STAIR_CX,
  STAIR_RISE,
  STAIR_RUN,
  STAIR_STEPS,
  STAIR_X0,
  STAIR_X1,
  STAIR_Z_END,
  STAIR_Z_START,
  stairEyeY,
  stairTread,
} from './stairs'

// ---------------------------------------------------------------- helpers
function part(
  zone: ZoneId,
  mat: MatKey,
  min: Vec3,
  max: Vec3,
  opts: { solid?: boolean; uv?: number } = {},
): Part {
  return {
    zone,
    mat,
    c: [(min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2],
    s: [max[0] - min[0], max[1] - min[1], max[2] - min[2]],
    ...opts,
  }
}

// ================================================================= SHELL
const shell: Part[] = [
  // Plinth and finished floors
  part('shell', 'concrete', [-8.4, 0, -5.9], [8.4, FL0 - 0.04, 4.2], { uv: 3 }),
  part('shell', 'floorStone', [-8.0, FL0 - 0.04, -5.5], [8.0, FL0, 4.0], { uv: 2.4 }),

  // Ground-floor walls
  part('shell', 'plaster', [-1.8, FL0, -5.7], [8.2, CEIL0, -5.5], { solid: true }), // back
  part('shell', 'travertine', [-8.2, FL0, -5.7], [-8.0, CEIL0, 4.1], { solid: true, uv: 2 }), // left
  part('shell', 'plaster', [8.0, FL0, -5.7], [8.2, CEIL0, 4.1], { solid: true }), // right
  part('shell', 'stoneDark', [-8.2, FL0, 3.9], [-1.8, CEIL0, 4.1], { solid: true, uv: 2.4 }), // front-left
  // Entry hall: timber-slat flanks, a door opening, a lintel
  part('shell', 'oak', [-1.9, FL0, 3.9], [-0.7, CEIL0, 4.1], { solid: true, uv: 1.2 }),
  part('shell', 'oak', [0.7, FL0, 3.9], [1.9, CEIL0, 4.1], { solid: true, uv: 1.2 }),
  part('shell', 'oak', [-0.7, 3.3, 3.9], [0.7, CEIL0, 4.1], { solid: true, uv: 1.2 }),
  part('shell', 'oak', [-1.9, FL0, 1.0], [-1.7, CEIL0 - 0.55, 3.9], { solid: true, uv: 1.2 }),
  part('shell', 'oak', [1.7, FL0, 1.0], [1.9, CEIL0 - 0.55, 3.9], { solid: true, uv: 1.2 }),
  // Front-right glazing, back-left glazing (black frames)
  part('shell', 'glass', [1.9, FL0, 3.95], [8.0, CEIL0 - 0.1, 4.0]),
  part('shell', 'glass', [-8.0, FL0, -5.62], [-1.8, CEIL0 - 0.1, -5.58]),
  part('shell', 'blackMetal', [1.9, FL0, 3.9], [8.0, FL0 + 0.1, 4.1]),
  part('shell', 'blackMetal', [1.9, CEIL0 - 0.12, 3.9], [8.0, CEIL0, 4.1]),
  part('shell', 'blackMetal', [-8.0, CEIL0 - 0.12, -5.7], [-1.8, CEIL0, -5.5]),
  part('shell', 'blackMetal', [-8.0, FL0, -5.7], [-1.8, FL0 + 0.1, -5.5]),
  ...[2.9, 3.9, 4.9, 5.9, 6.9].map((x) =>
    part('shell', 'blackMetal', [x - 0.04, FL0, 3.9], [x + 0.04, CEIL0, 4.1]),
  ),
  ...[-7, -6, -5, -4, -3, -2.2].map((x) =>
    part('shell', 'blackMetal', [x - 0.04, FL0, -5.7], [x + 0.04, CEIL0, -5.5]),
  ),

  // First-floor slab, with the stair void cut out
  part('shell', 'concrete', [-8.4, CEIL0, -5.9], [6.3, FL1, 4.2], { solid: true, uv: 3 }),
  part('shell', 'concrete', [6.3, CEIL0, 0.8], [8.4, FL1, 4.2], { solid: true, uv: 3 }),
  part('shell', 'concrete', [6.3, CEIL0, -5.9], [8.4, FL1, -5.2], { solid: true, uv: 3 }),
  // Warm timber soffit over the hall
  part('shell', 'oak', [-1.7, CEIL0 - 0.55, 1.0], [1.7, CEIL0 - 0.5, 3.9], { uv: 1.2 }),

  // Portico canopy: black slab, timber soffit, two columns
  part('shell', 'blackMetal', [-2.9, 3.4, 4.1], [2.9, 3.75, 6.5], { solid: true }),
  part('shell', 'oak', [-2.8, 3.36, 4.1], [2.8, 3.4, 6.4], { uv: 1.2 }),
  part('shell', 'blackMetal', [-2.8, FL0, 6.25], [-2.55, 3.4, 6.5], { solid: true }),
  part('shell', 'blackMetal', [2.55, FL0, 6.25], [2.8, 3.4, 6.5], { solid: true }),
  // Portico platform and two shallow entry steps, lit along each nosing
  part('shell', 'stoneDark', [-3.4, 0, 4.0], [3.4, FL0, 6.3], { uv: 2.4 }),
  part('shell', 'stoneDark', [-3.8, 0, 6.3], [3.8, 0.3, 7.0], { uv: 2.4 }),
  part('shell', 'stoneDark', [-4.2, 0, 7.0], [4.2, 0.15, 7.7], { uv: 2.4 }),
  part('shell', 'led', [-3.7, 0.27, 6.28], [3.7, 0.3, 6.31]),
  part('shell', 'led', [-4.1, 0.12, 6.98], [4.1, 0.15, 7.01]),
  part('shell', 'led', [-4.2, 0.0, 7.69], [4.2, 0.03, 7.72]),

  // Upper bedroom volume: walls, glazed front, roof
  part('shell', 'plaster', [0.8, FL1, -5.7], [8.2, CEIL1, -5.5], { solid: true }), // back
  part('shell', 'travertine', [0.8, FL1, -5.7], [1.0, CEIL1, 2.2], { solid: true, uv: 2 }), // left
  part('shell', 'plaster', [8.0, FL1, -5.7], [8.2, CEIL1, 2.2], { solid: true }), // right
  part('shell', 'glass', [1.0, FL1, 2.04], [8.0, CEIL1 - 0.12, 2.1]),
  part('shell', 'blackMetal', [1.0, CEIL1 - 0.15, 2.0], [8.0, CEIL1, 2.2]),
  part('shell', 'blackMetal', [1.0, FL1, 2.0], [8.0, FL1 + 0.1, 2.2]),
  ...[1.1, 3.55, 6.05, 7.95].map((x) =>
    part('shell', 'blackMetal', [x - 0.05, FL1, 2.0], [x + 0.05, CEIL1, 2.2]),
  ),
  part('shell', 'blackMetal', [0.3, CEIL1, -6.2], [8.7, ROOF_TOP, 6.5], { solid: true }),

  // Balcony slab, stone side mass, glass balustrade
  part('shell', 'travertine', [2.8, FL1 - 0.4, 2.2], [8.2, FL1, 5.8], { solid: true, uv: 2 }),
  part('shell', 'travertine', [1.0, FL1, 2.2], [2.8, ROOF_TOP - 0.35, 5.8], { solid: true, uv: 2 }),
  part('shell', 'floorStone', [2.8, FL1, 2.2], [8.2, FL1 + 0.03, 5.8], { uv: 2.4 }),
  part('shell', 'glass', [2.8, FL1 + 0.03, 5.74], [8.2, FL1 + 1.1, 5.78]),
  part('shell', 'glass', [8.12, FL1 + 0.03, 2.2], [8.16, FL1 + 1.1, 5.8]),
  part('shell', 'blackMetal', [2.8, FL1 + 1.08, 5.72], [8.2, FL1 + 1.13, 5.8]),
  part('shell', 'blackMetal', [8.1, FL1 + 1.08, 2.2], [8.18, FL1 + 1.13, 5.8]),

  // Upper-left planted terrace: stone slab, timber-slat screen, glass edge
  part('shell', 'travertine', [-8.4, CEIL0, 4.2], [0.8, FL1, 5.8], { solid: true, uv: 2 }),
  part('shell', 'floorStone', [-8.4, FL1, -1.5], [0.8, FL1 + 0.03, 5.8], { uv: 2.4 }),
  part('shell', 'oak', [-8.2, FL1, -1.6], [0.8, FL1 + 3.0, -1.4], { solid: true, uv: 1.2 }),
  part('shell', 'glass', [-8.4, FL1 + 0.03, 5.74], [0.8, FL1 + 1.1, 5.78]),
  part('shell', 'glass', [-8.4, FL1 + 0.03, -1.4], [-8.36, FL1 + 1.1, 5.8]),
  part('shell', 'blackMetal', [-8.4, FL1 + 1.08, 5.72], [0.8, FL1 + 1.13, 5.8]),

  // Dark stone gate wall + planter in front of the left of the house
  part('shell', 'stoneDark', [-10.8, 0, 5.0], [-3.4, 3.3, 5.3], { solid: true, uv: 2.4 }),
  part('shell', 'concrete', [-10.6, 0, 5.3], [-3.6, 0.45, 6.2], { uv: 2 }),
]

// ============================================================ INTERIORS
const hall: Part[] = [
  part('hall', 'led', [-1.74, FL0 + 0.4, 1.4], [-1.7, CEIL0 - 0.7, 1.46]),
  part('hall', 'led', [1.7, FL0 + 0.4, 1.4], [1.74, CEIL0 - 0.7, 1.46]),
  part('hall', 'stoneDark', [-1.6, FL0, 1.1], [-0.9, FL0 + 0.85, 1.7], { uv: 1.5 }), // console
  part('hall', 'fabricDark', [-1.5, FL0 + 0.85, 1.2], [-1.0, FL0 + 0.95, 1.6]),
]

const living: Part[] = [
  // Rug, L-shaped sofa, armchair, coffee table, wall art
  part('living', 'fabricDark', [-7.2, FL0, -4.2], [-3.2, FL0 + 0.02, -0.4]),
  part('living', 'fabric', [-7.4, FL0, -4.6], [-4.2, FL0 + 0.42, -3.4], { solid: true }),
  part('living', 'fabric', [-7.4, FL0 + 0.42, -4.6], [-4.2, FL0 + 0.95, -4.3], { solid: true }),
  part('living', 'fabric', [-7.4, FL0, -3.4], [-6.3, FL0 + 0.42, -1.7], { solid: true }),
  part('living', 'fabric', [-7.4, FL0 + 0.42, -3.4], [-7.1, FL0 + 0.95, -1.7], { solid: true }),
  part('living', 'fabricDark', [-3.9, FL0, -3.7], [-3.0, FL0 + 0.45, -2.8], { solid: true }),
  part('living', 'fabricDark', [-3.4, FL0 + 0.45, -3.7], [-3.0, FL0 + 0.85, -2.8], { solid: true }),
  part('living', 'stoneDark', [-5.6, FL0, -3.0], [-4.3, FL0 + 0.38, -2.1], { solid: true, uv: 1 }),
  part('living', 'travertine', [-7.95, FL0 + 1.0, -3.4], [-7.9, FL0 + 2.5, -1.6], { uv: 1.2 }),
  part('living', 'led', [-7.9, FL0 + 0.95, -3.4], [-7.86, FL0 + 0.98, -1.6]),
  part('living', 'led', [-8.0, CEIL0 - 0.2, -5.4], [-2.0, CEIL0 - 0.16, -5.3]),
]

const dining: Part[] = [
  part('dining', 'oak', [-0.1, FL0 + 0.72, -3.55], [2.5, FL0 + 0.78, -2.45], {
    solid: true,
    uv: 1,
  }),
  part('dining', 'blackMetal', [0.2, FL0, -3.2], [0.35, FL0 + 0.72, -2.8], { solid: true }),
  part('dining', 'blackMetal', [2.05, FL0, -3.2], [2.2, FL0 + 0.72, -2.8], { solid: true }),
  part('dining', 'fabricDark', [-0.5, FL0, -4.2], [2.9, FL0 + 0.02, -1.8]),
  part('dining', 'oak', [-1.7, FL0, -5.5], [2.4, CEIL0 - 0.3, -5.45], { uv: 1.2 }), // slat wall
  part('dining', 'led', [-1.7, CEIL0 - 0.3, -5.45], [2.4, CEIL0 - 0.27, -5.4]),
]

const kitchen: Part[] = [
  part('kitchen', 'cabinet', [2.7, FL0, -2.6], [6.0, FL0 + 0.88, -1.6], { solid: true, uv: 1.5 }),
  part('kitchen', 'counter', [2.6, FL0 + 0.88, -2.7], [6.1, FL0 + 0.93, -1.5], {
    solid: true,
    uv: 1.5,
  }),
  part('kitchen', 'cabinet', [2.5, FL0, -5.5], [6.2, FL0 + 2.3, -4.9], { solid: true, uv: 1.5 }),
  part('kitchen', 'counter', [2.5, FL0 + 0.88, -5.0], [6.2, FL0 + 0.92, -4.9], { uv: 1.5 }),
  part('kitchen', 'led', [2.5, FL0 + 0.93, -5.0], [6.2, FL0 + 0.96, -4.95]),
  part('kitchen', 'led', [2.5, FL0 + 2.3, -5.5], [6.2, FL0 + 2.33, -4.9]),
  part('kitchen', 'blackMetal', [3.7, FL0 + 1.9, -5.0], [5.0, FL0 + 2.3, -4.7]),
  part('kitchen', 'led', [2.8, CEIL0 - 0.25, -3.2], [5.9, CEIL0 - 0.21, -3.12]),
  part('kitchen', 'led', [2.8, CEIL0 - 0.25, -1.0], [5.9, CEIL0 - 0.21, -0.92]),
]

const stair: Part[] = [
  part('stair', 'plaster', [7.7, FL0, -4.9], [8.0, FL1, 0.4], { uv: 2 }), // wall-wash backing
  part('stair', 'led', [7.7, FL0 + 0.1, -4.9], [7.74, FL1 - 0.1, -4.86]),
  part('stair', 'stoneDark', [6.5, FL0, 0.9], [7.8, FL0 + 0.04, 2.2], { uv: 1.5 }),
]

const bedroom: Part[] = [
  part('bedroom', 'floorOak', [1.0, FL1, -5.5], [6.3, FL1 + 0.03, 2.0], { uv: 1.6 }),
  part('bedroom', 'floorOak', [6.3, FL1, -5.5], [8.0, FL1 + 0.03, -5.2], { uv: 1.6 }),
  part('bedroom', 'fabricDark', [1.5, FL1 + 0.03, -3.9], [4.7, FL1 + 0.05, -0.5]), // rug
  // Bed with its head against the timber panel on the left wall, seen straight on from the stair
  part('bedroom', 'oak', [1.0, FL1 + 0.2, -3.7], [1.06, FL1 + 2.8, -0.7], { uv: 1.2 }),
  part('bedroom', 'led', [1.0, FL1 + 2.8, -3.7], [1.1, FL1 + 2.83, -0.7]),
  part('bedroom', 'oak', [1.1, FL1 + 0.03, -3.2], [3.4, FL1 + 0.4, -1.2], { solid: true, uv: 1 }),
  part('bedroom', 'linen', [1.2, FL1 + 0.4, -3.15], [3.35, FL1 + 0.62, -1.25], { solid: true }),
  part('bedroom', 'linen', [1.25, FL1 + 0.62, -3.0], [1.75, FL1 + 0.78, -2.2]),
  part('bedroom', 'linen', [1.25, FL1 + 0.62, -2.2], [1.75, FL1 + 0.78, -1.4]),
  part('bedroom', 'fabricDark', [2.3, FL1 + 0.62, -3.15], [3.0, FL1 + 0.66, -1.25]),
  part('bedroom', 'oak', [1.1, FL1 + 0.03, -3.9], [1.7, FL1 + 0.55, -3.3], { solid: true, uv: 1 }),
  part('bedroom', 'oak', [1.1, FL1 + 0.03, -1.1], [1.7, FL1 + 0.55, -0.5], { solid: true, uv: 1 }),
  part('bedroom', 'led', [1.3, FL1 + 0.55, -3.7], [1.5, FL1 + 0.75, -3.5]),
  part('bedroom', 'led', [1.3, FL1 + 0.55, -0.9], [1.5, FL1 + 0.75, -0.7]),
]

const balcony: Part[] = [
  part('balcony', 'blackMetal', [3.1, FL1 + 0.03, 3.5], [3.9, FL1 + 0.28, 5.1]),
  part('balcony', 'linen', [3.15, FL1 + 0.28, 3.55], [3.85, FL1 + 0.4, 5.05]),
  part('balcony', 'linen', [3.15, FL1 + 0.4, 3.55], [3.85, FL1 + 0.75, 3.8]),
  part('balcony', 'blackMetal', [5.8, FL1 + 0.03, 3.5], [6.6, FL1 + 0.28, 5.1]),
  part('balcony', 'linen', [5.85, FL1 + 0.28, 3.55], [6.55, FL1 + 0.4, 5.05]),
  part('balcony', 'linen', [5.85, FL1 + 0.4, 3.55], [6.55, FL1 + 0.75, 3.8]),
  part('balcony', 'stoneDark', [4.3, FL1 + 0.03, 4.4], [5.3, FL1 + 0.4, 5.0], { uv: 1 }),
]

const terrace: Part[] = [
  // Planter boxes along the terrace edge (shrubs are instanced in the scene)
  part('terrace', 'stoneDark', [-8.1, FL1 + 0.03, 5.1], [0.5, FL1 + 0.45, 5.6], { uv: 1.4 }),
  part('terrace', 'stoneDark', [-8.1, FL1 + 0.03, -1.3], [-7.6, FL1 + 0.45, 5.1], { uv: 1.4 }),
  part('terrace', 'blackMetal', [-5.0, FL1 + 0.03, 1.0], [-3.2, FL1 + 0.45, 2.6]),
  part('terrace', 'linen', [-4.95, FL1 + 0.45, 1.05], [-3.25, FL1 + 0.6, 2.55]),
]

const site: Part[] = [
  // Wet, dark paving all around (the ground plane)
  part('site', 'paving', [-60, -0.02, -60], [60, 0, 60], { uv: 4 }),
]

export const parts: readonly Part[] = [
  ...site,
  ...shell,
  ...hall,
  ...living,
  ...dining,
  ...kitchen,
  ...stair,
  ...bedroom,
  ...balcony,
  ...terrace,
]

/** Obstacles the camera must never pass through. */
export const solids: readonly Part[] = parts.filter((p) => p.solid)

// ------------------------------------------------------------ instances
/** Trees: trunk base (x, z) and canopy radius. Kept clear of the camera corridor. */
export const trees: ReadonlyArray<{ x: number; z: number; h: number; r: number }> = [
  { x: -14.5, z: 12.5, h: 5.6, r: 2.0 },
  { x: -13.0, z: 5.5, h: 6.0, r: 2.3 },
  { x: -11.0, z: -2.0, h: 5.5, r: 2.1 },
  { x: -10.2, z: -9.0, h: 6.4, r: 2.4 },
  { x: 11.5, z: 8.5, h: 5.0, r: 1.8 },
  { x: 12.2, z: 2.0, h: 5.8, r: 2.2 },
  { x: 10.5, z: -8.0, h: 6.2, r: 2.3 },
  { x: -2.0, z: -11.0, h: 6.0, r: 2.4 },
  { x: 3.0, z: -12.0, h: 6.6, r: 2.6 },
  { x: 14.5, z: -2.0, h: 7.0, r: 2.8 },
  { x: -6.5, z: 8.2, h: 3.6, r: 1.3 },
  { x: 6.8, z: 9.2, h: 3.4, r: 1.2 },
]

/** Low shrubs/planting: centre x, z, y base, radius. */
export const shrubs: ReadonlyArray<{ x: number; y: number; z: number; r: number }> = [
  ...[-9.8, -8.4, -7.0, -5.6, -4.2].map((x) => ({ x, y: 0.45, z: 5.75, r: 0.55 })),
  ...[-4.6, -3.9].map((x) => ({ x, y: 0, z: 8.2, r: 0.5 })),
  ...[3.9, 4.6, 5.8].map((x) => ({ x, y: 0, z: 8.4, r: 0.5 })),
  ...[-7.4, -6.2, -5.0, -3.8, -2.6, -1.4, -0.2].map((x) => ({
    x,
    y: FL1 + 0.45,
    z: 5.35,
    r: 0.42,
  })),
  ...[-0.3, 1.0, 2.0].map((x) => ({ x: x - 1.3, y: 0, z: 6.9, r: 0.45 })),
  { x: 8.8, y: 0, z: 4.4, r: 0.6 },
  { x: 9.6, y: 0, z: 3.8, r: 0.5 },
  { x: -1.6, y: FL0, z: 1.6, r: 0.35 },
]

/** Dining chairs: x, z, facing angle. */
export const chairs: ReadonlyArray<{ x: number; z: number; a: number }> = [
  { x: 0.3, z: -2.2, a: Math.PI },
  { x: 1.2, z: -2.2, a: Math.PI },
  { x: 2.1, z: -2.2, a: Math.PI },
  { x: 0.3, z: -3.8, a: 0 },
  { x: 1.2, z: -3.8, a: 0 },
  { x: 2.1, z: -3.8, a: 0 },
  { x: -0.55, z: -3.0, a: Math.PI / 2 },
  { x: 2.95, z: -3.0, a: -Math.PI / 2 },
]

export const stools: ReadonlyArray<{ x: number; z: number }> = [
  { x: 3.5, z: -1.25 },
  { x: 4.35, z: -1.25 },
  { x: 5.2, z: -1.25 },
]

export const pendants: ReadonlyArray<{ x: number; z: number }> = [
  { x: 0.4, z: -3.0 },
  { x: 1.2, z: -3.0 },
  { x: 2.0, z: -3.0 },
]

/** Recessed downlights: x, y, z (all on a ceiling or soffit). */
export const downlights: ReadonlyArray<Vec3> = [
  ...[-1.0, 0, 1.0].flatMap((x) => [2.0, 3.0].map((z) => [x, 3.34, z + 1.0] as const)),
  ...[-2.2, -0.8, 0.8, 2.2].flatMap((x) => [4.6, 5.6].map((z) => [x, 3.34, z] as const)),
  ...[-6.5, -4.5, -2.5].flatMap((x) => [-3.5, -1.2].map((z) => [x, CEIL0 - 0.02, z] as const)),
  ...[3.0, 5.0].flatMap((x) => [-0.2].map((z) => [x, CEIL0 - 0.02, z] as const)),
  ...[2.4, 4.0, 5.6].flatMap((x) => [-3.6, -0.8, 1.2].map((z) => [x, CEIL1 - 0.02, z] as const)),
]

// ---------------------------------------------------- camera classification
export type Region = 'exterior' | 'ground' | 'upper'

/** Which part of the house the camera is in — drives what can be culled. */
export function regionAt(x: number, y: number, z: number): Region {
  const insideFootprint = x > -8.1 && x < 8.1 && z > -5.6 && z < 4.0
  if (insideFootprint && y < FL1 - 0.3) return 'ground'
  const insideUpper = x > 0.9 && x < 8.1 && z > -5.6 && z < 2.1 && y > FL1 - 0.3 && y < CEIL1
  if (insideUpper) return 'upper'
  return 'exterior'
}
