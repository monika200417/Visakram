import { describe, expect, it } from 'vitest'
import {
  homeTourChapters,
  homeTourDisclaimer,
  homeTourHeading,
  homeTourTagline,
} from '../../src/data/homeTour'
import { waypoints } from '../../src/three/home-tour/waypoints'

describe('Home Tour data', () => {
  it('has the nine approved chapters in journey order with consistent numbering', () => {
    expect(homeTourChapters.map((c) => `${c.index} ${c.title}`)).toEqual([
      '01 Exterior',
      '02 Entry',
      '03 Living',
      '04 Dining',
      '05 Kitchen',
      '06 Staircase',
      '07 Bedroom',
      '08 Balcony',
      '09 Exterior Reveal',
    ])
    expect(homeTourHeading).toBe('Home Tour')
    expect(homeTourTagline).toBe('Experience spaces beyond walls.')
  })

  it('anchors every chapter on exactly one camera waypoint, in the same order', () => {
    const anchored = waypoints.filter((w) => w.chapter).map((w) => w.id)
    expect(anchored).toEqual(homeTourChapters.map((c) => c.id))
  })

  it('uses only the approved captions — no claim copy and no brand mark', () => {
    const copy = homeTourChapters.map((c) => `${c.title} ${c.caption}`).join(' ')
    expect(copy.toLowerCase()).not.toContain('superior construction')
    expect(copy.toLowerCase()).not.toContain('visakram')
    for (const c of homeTourChapters) expect(c.caption.length).toBeGreaterThan(10)
  })

  it('labels the residence as illustrative, not a specific project', () => {
    expect(homeTourDisclaimer).toMatch(/illustrative/i)
    expect(homeTourDisclaimer).toMatch(/not a specific/i)
  })
})
