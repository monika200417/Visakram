import { render, screen, within } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { homeTourChapters } from '../../src/data/homeTour'

/**
 * The Home Tour section, tested at the React boundary. The real 3D module is
 * replaced by a stand-in (see from-plan-to-place-eligible.test.tsx for the
 * same approach), so no Three.js/R3F is loaded in the test run.
 */
vi.mock('../../src/three/home-tour/HomeTourCanvas', () => ({
  default: ({ progressRef, onReady }: { progressRef: unknown; onReady: unknown }) => (
    <div
      data-testid="mock-home-tour-canvas"
      data-has-progress-ref={String(Boolean(progressRef))}
      data-has-ready={String(typeof onReady === 'function')}
    />
  ),
}))

const originalMatchMedia = window.matchMedia

function stubMatchMedia(desktopMotionOk: boolean) {
  window.matchMedia = ((query: string) => {
    const matches =
      desktopMotionOk && (query.includes('min-width: 1024px') || query.includes('no-preference'))
    return {
      matches,
      media: query,
      onchange: null,
      addEventListener: () => {},
      removeEventListener: () => {},
      addListener: () => {},
      removeListener: () => {},
      dispatchEvent: () => false,
    } as unknown as MediaQueryList
  }) as typeof window.matchMedia
}

afterEach(() => {
  window.matchMedia = originalMatchMedia
  vi.resetModules()
  vi.doUnmock('../../src/three/utils/detectWebglSupport')
})

async function renderSection(webgl: boolean) {
  vi.doMock('../../src/three/utils/detectWebglSupport', () => ({ detectWebglSupport: () => webgl }))
  const { HomeTourSection } =
    await import('../../src/sections/home/HomeTourSection/HomeTourSection')
  return render(<HomeTourSection />)
}

describe('Home Tour section — static fallback (mobile, reduced motion, no WebGL)', () => {
  beforeEach(() => stubMatchMedia(false))

  it('renders the heading, tagline, disclaimer and all nine chapters as real HTML', async () => {
    await renderSection(false)
    const heading = screen.getByRole('heading', { level: 2, name: 'Home Tour' })
    const section = heading.closest('section') as HTMLElement
    const scoped = within(section)
    expect(scoped.getByText('Experience spaces beyond walls.')).toBeInTheDocument()
    expect(scoped.getByText(/illustrative residence/i)).toBeInTheDocument()
    expect(scoped.getAllByRole('heading', { level: 3 }).map((h) => h.textContent)).toEqual(
      homeTourChapters.map((c) => c.title),
    )
    for (const c of homeTourChapters) expect(scoped.getByText(c.caption)).toBeInTheDocument()
  })

  it('never reaches for the 3D module and stays in static mode', async () => {
    await renderSection(false)
    expect(screen.queryByTestId('mock-home-tour-canvas')).toBeNull()
    expect(document.querySelector('#home-tour')?.getAttribute('data-mode')).toBe('static')
    // The SVG dusk elevation is the visual; it is decorative.
    expect(document.querySelector('#home-tour svg')?.getAttribute('aria-hidden')).toBe('true')
  })

  it('keeps the unbranded residence free of signage', async () => {
    await renderSection(false)
    const section = document.querySelector('#home-tour') as HTMLElement
    const visible = Array.from(section.querySelectorAll('h2, h3, p')).map((el) => el.textContent)
    // The only mention of the company is the disclaimer saying this is not one of its projects.
    expect(visible.filter((t) => /visakram/i.test(t ?? ''))).toHaveLength(1)
  })
})

describe('Home Tour section — canvas-eligible (desktop, motion ok, WebGL), mocked 3D module', () => {
  beforeEach(() => stubMatchMedia(true))

  it('switches to the pinned tour and hands the lazy module a shared progress ref and a ready callback', async () => {
    await renderSection(true)
    const canvas = await screen.findByTestId('mock-home-tour-canvas')
    expect(canvas).toHaveAttribute('data-has-progress-ref', 'true')
    expect(canvas).toHaveAttribute('data-has-ready', 'true')
    expect(document.querySelector('#home-tour')?.getAttribute('data-mode')).toBe('tour')
  })

  it('still carries all nine chapters as text alongside the canvas (never replaced by it)', async () => {
    await renderSection(true)
    await screen.findByTestId('mock-home-tour-canvas')
    const section = document.querySelector('#home-tour') as HTMLElement
    expect(within(section).getAllByRole('heading', { level: 3, hidden: true })).toHaveLength(
      homeTourChapters.length,
    )
  })
})
