import { describe, expect, it } from 'vitest'
import { tour } from '../../src/three/home-tour/cameraPath'
import { solids } from '../../src/three/home-tour/layout'
import { waypoints } from '../../src/three/home-tour/waypoints'
import { homeTourChapters } from '../../src/data/homeTour'

const SAMPLES = 6000

function forward(p: number) {
  const s = tour.sample(p)
  const d = [s.lookAt[0] - s.position[0], s.lookAt[1] - s.position[1], s.lookAt[2] - s.position[2]]
  const len = Math.hypot(d[0]!, d[1]!, d[2]!)
  return d.map((v) => v / len) as [number, number, number]
}

const deg = (rad: number) => (rad * 180) / Math.PI

describe('Home Tour camera path', () => {
  it('derives one progress anchor per chapter, strictly increasing and well spread', () => {
    expect(tour.anchors).toHaveLength(homeTourChapters.length)
    expect(tour.chapterIds).toEqual(homeTourChapters.map((c) => c.id))
    tour.anchors.forEach((a, i) => {
      expect(a).toBeGreaterThan(0)
      expect(a).toBeLessThan(1)
      if (i > 0) expect(a - tour.anchors[i - 1]!).toBeGreaterThan(0.04)
    })
    expect(tour.anchors[0]!).toBeLessThan(0.1)
    expect(tour.anchors[tour.anchors.length - 1]!).toBeGreaterThan(0.9)
  })

  it('reaches every waypoint in order, never out of sequence', () => {
    const arrivals = waypoints.map((w) => tour.arrivalProgress[w.id]!)
    arrivals.forEach((a, i) => {
      expect(a).toBeGreaterThanOrEqual(0)
      expect(a).toBeLessThanOrEqual(1)
      if (i > 0) expect(a).toBeGreaterThan(arrivals[i - 1]!)
    })
  })

  it('maps progress to the right chapter and never skips or reverses one', () => {
    tour.anchors.forEach((a, i) => expect(tour.chapterIndexAt(a)).toBe(i))
    expect(tour.chapterIndexAt(0)).toBe(0)
    expect(tour.chapterIndexAt(1)).toBe(homeTourChapters.length - 1)
    let last = 0
    for (let i = 0; i <= SAMPLES; i++) {
      const c = tour.chapterIndexAt(i / SAMPLES)
      expect(c).toBeGreaterThanOrEqual(last)
      expect(c - last).toBeLessThanOrEqual(1)
      last = c
    }
  })

  it('starts and ends exactly on the first and last waypoints', () => {
    const first = waypoints[0]!
    const last = waypoints[waypoints.length - 1]!
    const a = tour.sample(0)
    const b = tour.sample(1)
    first.position.forEach((v, i) => expect(a.position[i]).toBeCloseTo(v, 3))
    last.position.forEach((v, i) => expect(b.position[i]).toBeCloseTo(v, 3))
  })

  it('never cuts: position, view direction and lens change smoothly between samples', () => {
    let maxStep = 0
    let maxTurn = 0
    let maxFov = 0
    let previous = tour.sample(0)
    let previousForward = forward(0)
    for (let i = 1; i <= SAMPLES; i++) {
      const p = i / SAMPLES
      const s = tour.sample(p)
      maxStep = Math.max(
        maxStep,
        Math.hypot(
          s.position[0] - previous.position[0],
          s.position[1] - previous.position[1],
          s.position[2] - previous.position[2],
        ),
      )
      const f = forward(p)
      const dot = f[0] * previousForward[0] + f[1] * previousForward[1] + f[2] * previousForward[2]
      maxTurn = Math.max(maxTurn, deg(Math.acos(Math.min(1, dot))))
      maxFov = Math.max(maxFov, Math.abs(s.fov - previous.fov))
      previous = s
      previousForward = f
    }
    // 6000 samples across the whole tour: no step is anything like a cut.
    expect(maxStep).toBeLessThan(0.15)
    expect(maxTurn).toBeLessThan(0.7)
    expect(maxFov).toBeLessThan(0.1)
  })

  it('turns the view gently: no more than ~30° of rotation per 1% of scroll', () => {
    // 1% of progress is roughly one scroll notch of a ~6,000 px pin, so a long
    // turn must be spread over enough scroll distance to feel like a camera move.
    const window = 60
    const dirs = Array.from({ length: SAMPLES + 1 }, (_, i) => forward(i / SAMPLES))
    let worst = 0
    for (let i = 0; i + window <= SAMPLES; i += 5) {
      const a = dirs[i]!
      const b = dirs[i + window]!
      const dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
      worst = Math.max(worst, deg(Math.acos(Math.min(1, dot))))
    }
    expect(worst).toBeLessThan(30)
  })

  it('lingers on each chapter: the camera is slower at an anchor than on average', () => {
    const speed = (p: number) => {
      const e = 0.0006
      const a = tour.sample(p - e).position
      const b = tour.sample(p + e).position
      return Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]) / (2 * e)
    }
    const mean = tour.pathLength / 1
    tour.anchors.forEach((a) => expect(speed(a)).toBeLessThan(mean * 0.35))
  })

  it('never passes through a wall, slab, column or large furnishing', () => {
    const margin = 0.22
    const offenders: string[] = []
    for (let i = 0; i <= 4000; i++) {
      const p = i / 4000
      const [x, y, z] = tour.sample(p).position
      for (const s of solids) {
        const inside =
          Math.abs(x - s.c[0]) < s.s[0] / 2 + margin &&
          Math.abs(y - s.c[1]) < s.s[1] / 2 + margin &&
          Math.abs(z - s.c[2]) < s.s[2] / 2 + margin
        if (inside)
          offenders.push(`p=${p.toFixed(3)} in ${s.mat} @ ${s.c.map((v) => v.toFixed(1))}`)
      }
    }
    expect(offenders.slice(0, 5)).toEqual([])
  })

  it('opens and closes on the same residence: matching view and lens, nearby positions', () => {
    const a = tour.sample(0)
    const b = tour.sample(1)
    b.lookAt.forEach((v, i) => expect(v).toBeCloseTo(a.lookAt[i]!, 6))
    expect(b.fov).toBe(a.fov)
    expect(
      Math.hypot(
        b.position[0] - a.position[0],
        b.position[1] - a.position[1],
        b.position[2] - a.position[2],
      ),
    ).toBeLessThan(2.5)
  })
})
