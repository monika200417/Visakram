import { describe, expect, it } from 'vitest'
import { tour } from '../../src/three/home-tour/cameraPath'
import {
  POOL_SIZE,
  doorOpen,
  glassOpen,
  lightStations,
  pooledLights,
} from '../../src/three/home-tour/choreography'

const STEPS = 4000

describe('Home Tour choreography', () => {
  it('opens the front door only as the camera approaches the entry, and never closes it again', () => {
    expect(doorOpen(0)).toBe(0)
    expect(doorOpen(tour.arrivalProgress.entry!)).toBeCloseTo(1, 5)
    expect(doorOpen(1)).toBe(1)
    let last = 0
    for (let i = 0; i <= STEPS; i++) {
      const v = doorOpen(i / STEPS)
      expect(v).toBeGreaterThanOrEqual(last - 1e-9)
      expect(v).toBeLessThanOrEqual(1)
      last = v
    }
  })

  it('slides the balcony glass open between the bedroom and the balcony', () => {
    expect(glassOpen(tour.arrivalProgress.bedroom!)).toBe(0)
    expect(glassOpen(tour.arrivalProgress.balconyApproach!)).toBeCloseTo(1, 5)
    expect(glassOpen(tour.arrivalProgress.balcony!)).toBe(1)
  })

  it('always drives exactly three pooled lights — the count never changes', () => {
    for (let i = 0; i <= 200; i++) expect(pooledLights(i / 200)).toHaveLength(POOL_SIZE)
  })

  it('moves a light to its next station only when its intensity is effectively zero (no pops)', () => {
    let previous = pooledLights(0)
    let maxJump = 0
    for (let i = 1; i <= STEPS; i++) {
      const next = pooledLights(i / STEPS)
      next.forEach((light, m) => {
        const before = previous[m]!
        const moved =
          light.position[0] !== before.position[0] ||
          light.position[1] !== before.position[1] ||
          light.position[2] !== before.position[2]
        if (moved) expect(Math.max(light.intensity, before.intensity)).toBeLessThan(0.05)
        maxJump = Math.max(maxJump, Math.abs(light.intensity - before.intensity))
      })
      previous = next
    }
    // 4,000 steps across the tour: intensity changes smoothly everywhere.
    expect(maxJump).toBeLessThan(2.5)
  })

  it('lights the closing exterior exactly like the opening one', () => {
    const a = pooledLights(0)
    const b = pooledLights(1)
    a.forEach((light, m) => {
      expect(b[m]!.position).toEqual(light.position)
      expect(b[m]!.intensity).toBeCloseTo(light.intensity, 1)
    })
  })

  it('places a station of light in every chapter it should', () => {
    expect(lightStations.length).toBeGreaterThanOrEqual(tour.anchors.length)
  })
})
